﻿/*
DataSalud_Peru - CARGA DE DATOS
IMPORTANTE:
1) Extrae TODO el ZIP en C:\DataSalud_Peru
2) Verifica que existan:
   C:\DataSalud_Peru\Datos\Atenciones_Ambulatorias.csv
   C:\DataSalud_Peru\Datos\Vacunacion.csv
3) Si usas otra carpeta, cambia las dos rutas de BULK INSERT.
4) La cuenta del servicio de SQL Server debe tener permiso de LECTURA
   sobre la carpeta Datos. Si aparece "Access is denied", concede ese permiso.
5) Ejecuta este script completo en SSMS, en una sola ventana/conexión.
*/
USE DataSalud_Peru;
GO

SET NOCOUNT ON;
DECLARE @FilasAtenciones INT;
DECLARE @InsertadasAtenciones INT;
DECLARE @FilasVacunacion INT;
DECLARE @InsertadasVacunacion INT;

IF OBJECT_ID('tempdb..#AtencionesImport') IS NOT NULL DROP TABLE #AtencionesImport;
CREATE TABLE #AtencionesImport (
    id_persona VARCHAR(4000) NULL,
    Edad VARCHAR(4000) NULL,
    Tipo_edad VARCHAR(4000) NULL,
    Sexo VARCHAR(4000) NULL,
    id_ubigeo VARCHAR(4000) NULL,
    Fecha_atencion VARCHAR(4000) NULL,
    Diagnostico VARCHAR(4000) NULL,
    Tipo_Dx VARCHAR(4000) NULL,
    id_eess VARCHAR(4000) NULL
);

BULK INSERT #AtencionesImport
FROM 'C:\DataSalud_Peru\Datos\Atenciones_Ambulatorias.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ';',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001',
    TABLOCK,
    KEEPNULLS
);

SET @FilasAtenciones = @@ROWCOUNT;

INSERT INTO stg.AtencionAmbulatoria
    (id_persona, Edad, Tipo_edad, Sexo, id_ubigeo, Fecha_atencion, Diagnostico, Tipo_Dx, id_eess)
SELECT
    NULLIF(id_persona, ''), NULLIF(Edad, ''), NULLIF(Tipo_edad, ''),
    NULLIF(Sexo, ''), NULLIF(id_ubigeo, ''), NULLIF(Fecha_atencion, ''),
    NULLIF(Diagnostico, ''), NULLIF(Tipo_Dx, ''), NULLIF(id_eess, '')
FROM #AtencionesImport;

SET @InsertadasAtenciones = @@ROWCOUNT;

IF OBJECT_ID('tempdb..#VacunacionImport') IS NOT NULL DROP TABLE #VacunacionImport;
CREATE TABLE #VacunacionImport (
    GRUPO_RIESGO VARCHAR(4000) NULL,
    EDAD VARCHAR(4000) NULL,
    SEXO VARCHAR(4000) NULL,
    FECHA_VACUNACION VARCHAR(4000) NULL,
    DOSIS VARCHAR(4000) NULL,
    FABRICANTE VARCHAR(4000) NULL,
    DIRESA VARCHAR(4000) NULL,
    DEPARTAMENTO VARCHAR(4000) NULL,
    PROVINCIA VARCHAR(4000) NULL,
    DISTRITO VARCHAR(4000) NULL
);

BULK INSERT #VacunacionImport
FROM 'C:\DataSalud_Peru\Datos\Vacunacion.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ';',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001',
    TABLOCK,
    KEEPNULLS
);

SET @FilasVacunacion = @@ROWCOUNT;

INSERT INTO stg.Vacunacion
    (GRUPO_RIESGO, EDAD, SEXO, FECHA_VACUNACION, DOSIS, FABRICANTE,
     DIRESA, DEPARTAMENTO, PROVINCIA, DISTRITO)
SELECT
    NULLIF(GRUPO_RIESGO, ''), NULLIF(EDAD, ''), NULLIF(SEXO, ''),
    NULLIF(FECHA_VACUNACION, ''), NULLIF(DOSIS, ''), NULLIF(FABRICANTE, ''),
    NULLIF(DIRESA, ''), NULLIF(DEPARTAMENTO, ''), NULLIF(PROVINCIA, ''),
    NULLIF(DISTRITO, '')
FROM #VacunacionImport;

SET @InsertadasVacunacion = @@ROWCOUNT;

INSERT INTO audit.LoteCarga
    (fuente, archivo, filas_leidas, filas_aceptadas, filas_rechazadas, estado)
VALUES
    ('AtencionAmbulatoria', 'Atenciones_Ambulatorias.csv',
     @FilasAtenciones, @InsertadasAtenciones,
     @FilasAtenciones - @InsertadasAtenciones, 'COMPLETADO'),
    ('Vacunacion', 'Vacunacion.csv',
     @FilasVacunacion, @InsertadasVacunacion,
     @FilasVacunacion - @InsertadasVacunacion, 'COMPLETADO');

PRINT 'Carga finalizada.';
SELECT 'AtencionAmbulatoria' AS Tabla, COUNT(*) AS TotalRegistros
FROM stg.AtencionAmbulatoria
UNION ALL
SELECT 'Vacunacion', COUNT(*) FROM stg.Vacunacion;

SELECT * FROM audit.LoteCarga ORDER BY lote_id DESC;
GO
