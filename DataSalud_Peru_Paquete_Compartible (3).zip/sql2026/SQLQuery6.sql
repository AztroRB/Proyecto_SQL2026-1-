INSERT INTO audit.LoteCarga (fuente, archivo, filas_leidas, filas_aceptadas, filas_rechazadas, estado)
VALUES
    ('AtencionAmbulatoria', 'Atenciones_Ambulatorias.csv', 4557, 4557, 0, 'COMPLETADO'),
    ('Vacunacion', '_Muestra(1).xlsx', 4558, 4558, 0, 'COMPLETADO');