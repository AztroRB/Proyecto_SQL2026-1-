-- PROYECTO DATASALUD PERU
-- Paso 1: crear la base de datos

IF DB_ID(N'DataSalud_Peru') IS NULL
BEGIN
    CREATE DATABASE DataSalud_Peru;
END;
GO

USE DataSalud_Peru;
GO

-- Crear los esquemas del proyecto

IF NOT EXISTS (
    SELECT 1 FROM sys.schemas WHERE name = 'stg'
)
    EXEC('CREATE SCHEMA stg');
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.schemas WHERE name = 'core'
)
    EXEC('CREATE SCHEMA core');
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.schemas WHERE name = 'audit'
)
    EXEC('CREATE SCHEMA audit');
GO

PRINT 'Base de datos DataSalud_Peru creada correctamente.';
GO

USE DataSalud_Peru;
GO

-- TABLA 1: REGISTRO DE ATENCIONES AMBULATORIAS
CREATE TABLE stg.AtencionAmbulatoria (
    id_registro BIGINT IDENTITY(1,1) PRIMARY KEY,
    id_persona VARCHAR(50) NULL,
    Edad VARCHAR(20) NULL,
    Tipo_edad VARCHAR(10) NULL,
    Sexo VARCHAR(20) NULL,
    id_ubigeo VARCHAR(20) NULL,
    Fecha_atencion VARCHAR(20) NULL,
    Diagnostico VARCHAR(30) NULL,
    Tipo_Dx VARCHAR(20) NULL,
    id_eess VARCHAR(30) NULL,
    fecha_carga DATETIME2 DEFAULT SYSDATETIME()
);
GO

-- TABLA 2: REGISTRO DE VACUNACION
CREATE TABLE stg.Vacunacion (
    id_registro BIGINT IDENTITY(1,1) PRIMARY KEY,
    GRUPO_RIESGO VARCHAR(150) NULL,
    EDAD VARCHAR(20) NULL,
    SEXO VARCHAR(20) NULL,
    FECHA_VACUNACION VARCHAR(30) NULL,
    DOSIS VARCHAR(20) NULL,
    FABRICANTE VARCHAR(100) NULL,
    DIRESA VARCHAR(150) NULL,
    DEPARTAMENTO VARCHAR(100) NULL,
    PROVINCIA VARCHAR(100) NULL,
    DISTRITO VARCHAR(100) NULL,
    fecha_carga DATETIME2 DEFAULT SYSDATETIME()
);
GO

-- TABLA 3: CONTROL DE CARGAS
CREATE TABLE audit.LoteCarga (
    lote_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    fuente VARCHAR(100) NOT NULL,
    archivo VARCHAR(260) NOT NULL,
    fecha_carga DATETIME2 DEFAULT SYSDATETIME(),
    filas_leidas INT NULL,
    filas_aceptadas INT NULL,
    filas_rechazadas INT NULL,
    estado VARCHAR(30) DEFAULT 'INICIADO'
);
GO

PRINT 'Las tres tablas se crearon correctamente.';
GO
